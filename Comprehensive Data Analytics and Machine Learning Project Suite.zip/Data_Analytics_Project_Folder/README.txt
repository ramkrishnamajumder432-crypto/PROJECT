
DATA ANALYTICS PROJECT STRUCTURE

Level 1:
- Data Cleaning
- EDA
- Data Visualization

Level 2:
- Regression Analysis
- Time Series Analysis
- Clustering Analysis

Level 3:
- Classification
- Dashboard Task
- Sentiment Analysis

Datasets Used:
- Iris Dataset
- Stock Prices Dataset
- Sentiment Dataset
- House Prediction Dataset
- Churn Dataset
